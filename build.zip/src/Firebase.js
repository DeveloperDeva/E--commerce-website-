import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyDft7Jz56EjpIGvpduxEfWsKGo8pQG6HJI",
    authDomain: "clone-29a6a.firebaseapp.com",
    projectId: "clone-29a6a",
    storageBucket: "clone-29a6a.appspot.com",
    messagingSenderId: "840480082814",
    appId: "1:840480082814:web:f98e792adec58b919e812f",
    measurementId: "G-T0W4QZW5EG"
  };

  const firebaseApp = firebase.initializeApp(firebaseConfig); 

  const db = firebaseApp.firestore();
  const auth = firebase.auth();

  export {db, auth};