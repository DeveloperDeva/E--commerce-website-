import React, { useEffect } from "react";
import './App.css';
import {BrowserRouter as Router, Routes, Route} from "react-router-dom"
// import Login from './pages/Login';
import Header from './pages/Header';
import { Link } from 'react-router-dom';
import Home from "./pages/Home";
import {StateProvider, useStateValue } from './StateProvider';
import reducer, {initialState} from "./reducer";
import Cheackout from "./pages/Cheackout";
import Login from "./pages/Login";
import { auth } from "./Firebase";
// import { Routes } from "react-router-dom";
function App() {
  const [{}, dispatch]= useStateValue();

  useEffect(() => {
    //will only run once when the app component loads......

    auth.onAuthStateChanged(authUser => {
      // console.log('THE USER IS >>>', authUser);

      if (authUser){
        //the user just log innn

        dispatch({
          type: 'SET_USER',
          user: authUser
        })
      }else{
        //the user is loged out
        dispatch({
          type: 'SET_USER',
          user: null
        })
      }
    })
  }, [])
  return (
    <StateProvider initialState={initialState} reducer={reducer}>
      <div className="App">
        <Routes>
          <Route exact path="/checkout" 
            element={<><Header/><Cheackout/></>}/>
          {/* <Route exact path="/login" element={<Login/>}/> */}
          <Route exact path="/"
            element={<><Header/><Home/></>}/>
        </Routes>  
      </div>
    </StateProvider>
  );
}

export default App;
