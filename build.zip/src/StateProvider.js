//setup Data layer
//we need this totrack the backet

import React,{createContext, useContext, useReducer} from "react";

//import Data Layer
export const StateContex = createContext();

//Build a provider
export const StateProvider=({reducer, initialState, children }) =>(

    <StateContex.Provider value= {useReducer(reducer, initialState)}>
        {children}
    </StateContex.Provider>
);

//This is how we use inside of the component
export const useStateValue = ()=> useContext(StateContex);
export default StateProvider;