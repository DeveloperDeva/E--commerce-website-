import React from 'react'
import "../css/Header.css";
import { Link } from 'react-router-dom';
import SearchIcon from '@mui/icons-material/Search';
import ShoppingBasketIcon from '@mui/icons-material/ShoppingBasket';
import { useStateValue, user } from '../StateProvider';
import {auth} from '../Firebase';

function Header() {
      const[{basket, user}]= useStateValue();
      
      const handleAuthentication = ()=> {
            if (user){
              auth.signOut()
            }
      }
      console.log("This is the user", user)
      // console.log(basket);

      return <div className='header'>

            {/* Logo on the left */}
            <Link to="/">
                  <img className="header__logo" src="https://pngimg.com/uploads/amazon/amazon_PNG11.png" alt="Amazon logo"></img>
            </Link>

            {/*Serch box */}
            <div className='header__search'>
                  <input type="text" className='header__searchInput' />
                  <SearchIcon className='header__searchIcon' />
            </div>


            {/* 3 links*/}
            <div className='header__nav'>
                  {/* {1st link} */}
                  <Link to={!user && "/login"} className='header__link'>
                     <div onClick={handleAuthentication}              className='header__opetion'>

                        <span className='header__lineOne'>Hellow Gust</span>
                        <span className='header__lineTwo'>{user ? 'Sign Out' : 'Sign In'}</span>
                     </div>
                  </Link>

                  {/* {2nd link} */}
                  <Link to="/checkout" className='header__link'>
                        <div className='header__opetion'>

                        <span className='header__lineOne'>Returns</span>
                        <span className='header__lineTwo'>Orders</span>
                        </div>
                  </Link>

                  {/* {3rd link} */}
                  <Link to="/checkout" className='header__link'>
                        <div className='header__opetion'>

                        <span className='header__lineOne'>Your</span>
                        <span className='header__lineTwo'>Prime</span>
                        </div>
                  </Link>

                  {/*4th link */}
                  <Link to="/checkout" className="header_link">
                        <div className='header_optionBasket'>
                        {/* {shopping basket icon} */}
                              <ShoppingBasketIcon/>

                        {/* {Number of itams in basket} */}
                              <span className="header_basketCount">{basket?.length}</span>
                        </div>
                  </Link>
                  

            </div>
                    {/* Basket icon with numbers*/}
      </div>

}

export default Header
