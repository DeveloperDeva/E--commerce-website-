import React, {useState, useEffect} from 'react'
import '../css/Login.css'
import { Link, useNavigate} from 'react-router-dom';
import {auth, } from '../Firebase';
import {StateProvider, useStateValue } from '../StateProvider';
// import{signInWithEmailAndPassword}from 'firebase/auth'
// import firebase from 'firebase'
function Login() {
  const navigate = useNavigate ();
  const[email, setEmail] = useState('');
  const[password, setPassword] = useState('');
  const [{}, dispatch]= useStateValue();

  // useEffect(() => {
  //   //will only run once when the app component loads......

  //   auth.onAuthStateChanged(authUser => {
  //     console.log('THE authUser IS >>>', authUser);

      
      // else{
  //       //the user is loged out
  //       dispatch({
  //         type: 'SET_USER',
  //         user: null
  //       })
  //     }
      
  //   })
  // }, [])
  const signIn= e =>{
        e.preventDefault();
        //Firebase login things
        auth
            .signInWithEmailAndPassword(email, password)
            .then(auth =>{
              if (auth){
                //the user just log innn
        
                dispatch({
                  type: 'SET_USER',
                  user: auth
                })
              }
              navigate("/")
            })
            .catch(error => alert(error.message))
  }

  const register = e => {
    e.preventDefault();
    auth
        .createUserWithEmailAndPassword(email, password)
        .then((auth)=> {
          //then succesfully created a new user with email and password
          // console.log(auth);
          if(auth) {
            navigate("/");
          }
        })
        .catch(error => alert(error.message))
  }

  return (
    <div className='login'>
      <Link to = '/'>
      <img className='login_logo' src='https://icon-library.com/images/amazon-icon-vector/amazon-icon-vector-13.jpg'/>
      </Link>
      <div className='Login_container'>
          <h1>Sign-in</h1>
          <form>
            <h5>E-Mail</h5>
            <input type='text' value={email} onChange={e=> setEmail(e.target.value)}></input>


            <h5>Password</h5>
            <input type='password' value={password} onChange={e=> setPassword(e.target.value)}/>

            <button type='submit' onClick={signIn} 
            className='Log_inSignINButton'>Sign IN</button>
          </form>

          <p>
          By continuing, you agree to Amazon's Conditions of Use and Privacy Notice.
          </p>

          <button onClick={register} className='Login_registerButton'>Create your Amazon Accaunt</button>
      </div>


    </div>

    
  )
}

export default Login
