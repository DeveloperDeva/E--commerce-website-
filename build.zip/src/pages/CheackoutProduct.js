import React from 'react'
import "../css/CheackoutProduct.css"
import { useStateValue } from '../StateProvider';
function CheackoutProduct({id, title, image, price, rating}) {

    const [{basket}, dispatch]= useStateValue();
    console.log(id, title, image, price, rating);
    const removeFromBasket = ()=> {
        //remove items from basket....
        dispatch({
            type: 'REMOVE_FROM_BASKET',
            id: id,
        });
    }
  return (
    <div className="CheakoutProduct">
        <img className="CheakoutProduct_img" src={image} alt="" />

        <div className="CheackoutProduct_info">
            <p className="CheackoutProduct_title">{title} </p>
            <p className="CheackoutProduct_price">
                <small>$</small>
                <strong>{price}</strong>
                
            </p>
            <div className="CheackoutProduct_rating">
            {Array(rating)
                .fill()
                .map((_)=>(
                    <p>⭐</p>
                ))}
            </div>

            <button onClick={removeFromBasket}>Remove From Basket</button>
        </div>
      
    </div>
  );
}

export default CheackoutProduct;
