import React from 'react'
import { useStateValue } from '../StateProvider';
import "../css/Cheackout.css";
import CheackoutProduct from "./CheackoutProduct";
import Subtotal from './Subtotal';
import CurrencyFormat from 'react-currency-format';
function Cheackout() {
    const[{basket}] = useStateValue();

    return (
    <div className="cheackout">
        <div className="cheackout_left">
        <img className="cheackout_ad" src="https://imagzes-eu.ssl-images-amazon.com/images/G/31/img21/Hero/revised/pd23/GW_Tallhero_3000x1200_cam._CB601659979_.jpg" alt="Loading..."></img>
        {basket?.length===0 ? (
            <div>
                <h2>Your Shopiping Basket is Empty</h2>
                <p>Your shopping cart is waiting. Give it purpose – fill it with groceries, clothing, household supplies, electronics and more.
                Continue shopping on the Amazon.in homepage, learn about today's deals, or visit your Wish List.</p>

                {/* {List out all the products } */}
               
            </div>

        ) : (
            <div>
                <h2 className="cheackout_title">Your Shopping Basket</h2>
                {basket?.map((item) => {
                    console.log(item);
                    return(
                       <CheackoutProduct
                        id={item.id}
                        title= {item.title}
                        image={item.image}
                        price={item.price}
                        rating={item.rating}/>
                    );
                })}
            </div>
        )}
        </div>
        {basket.length > 0 &&(
            <div className="cheackout_right">
                
                <Subtotal/>
            </div>
        )}
        
    </div>
  )
}

export default Cheackout
