import React from 'react'
import "../css/Home.css";
import Product from './Product';
function Home() {
  return (
    <div className="home">
        <img className="home_image" src="https://images-eu.ssl-images-amazon.com/images/G/31/prime/ACQ/PD23/PC_Hero_3000x1200_KV_FT_eng._CB601620731_.jpg" alt="loading..."/>

      {/* {Product 1}  id, title, price, rating, image */}
      <div className="home_row">
        <Product 
       id="123456"
       title="Up to 70% off | Electronics clearance store"
       price={11.96}
       rating={5}
       image="https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" alt="Loading 2..." />

        <Product 
       id="123456"
       title="Up to 70% off | Electronics clearance store"
       price={11.96}
       rating={5}
       image="https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" alt="Loading 2..." />
      </div>
      
      <div className="home_row">
        <Product 
       id="123456"
       title="Up to 70% off | Electronics clearance store"
       price={11.96}
       rating={5}
       image="https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" alt="Loading 2..." />

        <Product 
       id="123456"
       title="Up to 70% off | Electronics clearance store"
       price={11.96}
       rating={5}
       image="https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" alt="Loading 2..." />

        <Product 
       id="123456"
       title="Up to 70% off | Electronics clearance store"
       price={11.96}
       rating={5}
       image="https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" alt="Loading 2..." />
      </div>

      <div className="home_row">
        <Product 
       id="123456"
       title="Up to 70% off | Electronics clearance store"
       price={11.96}
       rating={5}
       image="https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" alt="Loading 2..." />
      </div>
    </div>
  )
}

export default Home
