
export const initialState={
    basket:[
        {
            id:"123456",
       title:"Up to 70% off | Electronics clearance store",
       price:11.96,
       rating:5,
       image:"https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" 
        },

        {
            id:"123456",
       title:"Up to 70% off | Electronics clearance store",
       price:12.96,
       rating:5,
       image:"https://images-eu.ssl-images-amazon.com/images/G/31/img22/Electronics/Clearance/Clearance_store_Desktop_CC_1x._SY304_CB628315133_.jpg" 
        },
    ],
    user: null,
};

export const getBasketTotal = (basket) =>
    basket?.reduce((amount, item) => item.price + amount, 0);
    

const reducer = (state, action) => {
    console.log(action.type);
    switch(action.type){
        case 'ADD_TO_BASKET':
            //Logic for adding to basket
            return{
                ...state,
                basket:[...state.basket, action.item],
            
            };
           
            
        case 'REMOVE_FROM_BASKET':
            //Logic for Removing items from basket
           let newBasket = [...state.basket];
           const index = state.basket.findIndex((basketItem)=> basketItem.id ===action.id );

           if (index >= 0){
            //item exista in basket, remove that...
            newBasket.splice(index, 1);
           }else{
            console.warn(
                'cant remove product (id: ${action.id}) as its not in basket '
            );
           }
           return{
            ...state, basket: newBasket,
            };

        case "SET_USER":
            return{
                ...state,
                user: action.user
            }
        //    break;
        default:
            return state;
    
    }
}
export default reducer